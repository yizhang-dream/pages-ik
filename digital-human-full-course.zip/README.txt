Digital Human IK course: 7 chapters / 47 lessons, Chinese and English.
Open learn.html. The English explanation follows the Chinese explanation on narrow screens.
Use the elbow-circle derivation before the pole lesson. Drafts remain local to the browser origin.
